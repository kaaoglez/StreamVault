'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { useAppStore, type Movie } from '@/store/app-store';
import { MovieCard } from './MovieCard';

export function SearchOverlay() {
  const { isSearchOpen, searchQuery, setSearch, closeSearch } = useAppStore();
  const inputRef = useRef<HTMLInputElement>(null);
  const [results, setResults] = useState<Movie[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const debounceRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isSearchOpen) {
      document.body.style.overflow = 'hidden';
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      document.body.style.overflow = '';
      setResults([]);
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isSearchOpen]);

  const handleSearch = useCallback((query: string) => {
    setSearch(query);
    if (debounceRef.current) clearTimeout(debounceRef.current);

    if (!query.trim()) {
      setResults([]);
      return;
    }

    setIsSearching(true);
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch(
          `/api/movies?search=${encodeURIComponent(query.trim())}&limit=20`
        );
        if (res.ok) {
          const data = await res.json();
          setResults(data.movies || []);
        }
      } catch {
        // silently fail
      } finally {
        setIsSearching(false);
      }
    }, 300);
  }, [setSearch]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isSearchOpen) {
        closeSearch();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSearchOpen, closeSearch]);

  if (!isSearchOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[80]"
      >
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-[#141414]/95 backdrop-blur-md"
          onClick={closeSearch}
        />

        {/* Content */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
          className="relative z-10 max-w-4xl mx-auto px-4 pt-8 pb-20 overflow-y-auto h-full"
        >
          {/* Search Input */}
          <div className="flex items-center gap-4 mb-8">
            <Search className="h-6 w-6 text-gray-400 shrink-0" />
            <Input
              ref={inputRef}
              type="text"
              placeholder="Buscar películas, series..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="flex-1 h-14 bg-transparent border-white/20 text-white text-xl placeholder:text-gray-600 focus:border-[#e50914] rounded-md"
            />
            <button
              onClick={closeSearch}
              className="shrink-0 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
              aria-label="Close search"
            >
              <X className="h-5 w-5 text-white" />
            </button>
          </div>

          {/* Results */}
          {searchQuery.trim() && (
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">
                {isSearching
                  ? 'Buscando...'
                  : results.length > 0
                    ? `Resultados para "${searchQuery}"`
                    : 'No se encontraron resultados'}
              </h3>

              {isSearching ? (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
                  {Array.from({ length: 12 }).map((_, i) => (
                    <div
                      key={i}
                      className="aspect-[2/3] bg-[#222] rounded-lg animate-pulse"
                    />
                  ))}
                </div>
              ) : results.length > 0 ? (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
                  {results.map((movie) => (
                    <MovieCard key={movie.id} movie={movie} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-20">
                  <Search className="h-12 w-12 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-500 text-lg">
                    Intenta buscar otra película o serie
                  </p>
                </div>
              )}
            </div>
          )}

          {!searchQuery.trim() && (
            <div className="text-center py-20">
              <p className="text-gray-500 text-lg">
                Escribe algo para comenzar a buscar
              </p>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
