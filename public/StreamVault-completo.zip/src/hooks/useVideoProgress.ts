'use client';

import { useState, useEffect, useCallback, useRef } from 'react';

interface VideoProgressData {
  position: number;
  duration: number;
  updatedAt: string;
}

interface UseVideoProgressOptions {
  videoPath: string | null;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  movieId?: string | null;
  episodeId?: string | null;
  minResumeSeconds?: number;
  saveInterval?: number;
}

const STORAGE_KEY_PREFIX = 'sv_progress_';

function getStorageKey(videoId: string): string {
  return STORAGE_KEY_PREFIX + videoId;
}

function loadFromStorage(videoId: string): VideoProgressData | null {
  try {
    const raw = localStorage.getItem(getStorageKey(videoId));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as VideoProgressData;
    // Ignore progress older than 30 days
    if (parsed.updatedAt) {
      const age = Date.now() - new Date(parsed.updatedAt).getTime();
      if (age > 30 * 24 * 60 * 60 * 1000) return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function saveToStorage(videoId: string, position: number, duration: number): void {
  try {
    localStorage.setItem(getStorageKey(videoId), JSON.stringify({
      position,
      duration,
      updatedAt: new Date().toISOString(),
    }));
  } catch { /* storage full or unavailable */ }
}

function removeFromStorage(videoId: string): void {
  try {
    localStorage.removeItem(getStorageKey(videoId));
  } catch { /* ignore */ }
}

// Save progress to server API (fire and forget)
async function saveToServer(movieId: string, episodeId: string | null | undefined, progress: number) {
  try {
    await fetch('/api/watch-progress', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ movieId, episodeId, progress }),
    });
  } catch { /* ignore network errors */ }
}

export function useVideoProgress({
  videoPath,
  videoRef,
  movieId,
  episodeId,
  minResumeSeconds = 30,
  saveInterval = 5,
}: UseVideoProgressOptions) {
  const [savedProgress, setSavedProgress] = useState<VideoProgressData | null>(null);
  const [showResumePrompt, setShowResumePrompt] = useState(false);
  const [hasResumed, setHasResumed] = useState(false);
  const saveTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastLoadedIdRef = useRef<string | null>(null);
  const movieIdRef = useRef(movieId);
  const episodeIdRef = useRef(episodeId);
  const videoPathRef = useRef(videoPath);

  useEffect(() => { movieIdRef.current = movieId; }, [movieId]);
  useEffect(() => { episodeIdRef.current = episodeId; }, [episodeId]);
  useEffect(() => { videoPathRef.current = videoPath; }, [videoPath]);

  const formatTime = useCallback((seconds: number): string => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) {
      return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }
    return `${m}:${String(s).padStart(2, '0')}`;
  }, []);

  const clearSaveTimer = useCallback(() => {
    if (saveTimerRef.current) {
      clearInterval(saveTimerRef.current);
      saveTimerRef.current = null;
    }
  }, []);

  const saveCurrentPosition = useCallback(() => {
    const path = videoPathRef.current;
    const mid = movieIdRef.current;
    const eid = episodeIdRef.current;
    if (!videoRef.current || !path || !mid) return;

    const video = videoRef.current;
    const position = video.currentTime;
    const duration = video.duration || 0;

    if (position < 2 || !isFinite(duration) || duration === 0) return;

    const progressPercent = (position / duration) * 100;

    // If video ended (within last 2 seconds), clear saved progress and mark as fully watched
    if (position >= duration - 2) {
      removeFromStorage(mid);
      saveToServer(mid, eid, 100);
      return;
    }

    saveToStorage(mid, position, duration);

    // Save to server at lower frequency (via timer)
    // Server save happens in the interval
  }, [videoRef]);

  const saveToServerAndStorage = useCallback(() => {
    const mid = movieIdRef.current;
    const eid = episodeIdRef.current;
    if (!videoRef.current || !mid) return;

    const video = videoRef.current;
    const position = video.currentTime;
    const duration = video.duration || 0;

    if (position < 2 || !isFinite(duration) || duration === 0) return;

    const progressPercent = (position / duration) * 100;

    if (position >= duration - 2) {
      removeFromStorage(mid);
      saveToServer(mid, eid, 100);
      return;
    }

    saveToStorage(mid, position, duration);
    saveToServer(mid, eid, progressPercent);
  }, [videoRef]);

  const startSaveTimer = useCallback(() => {
    clearSaveTimer();
    saveTimerRef.current = setInterval(() => {
      saveToServerAndStorage();
    }, saveInterval * 1000);
  }, [clearSaveTimer, saveToServerAndStorage, saveInterval]);

  // Load progress when movieId changes
  useEffect(() => {
    clearSaveTimer();

    if (!movieId) {
      lastLoadedIdRef.current = null;
      return;
    }

    if (movieId === lastLoadedIdRef.current) return;
    lastLoadedIdRef.current = movieId;

    const applyProgress = () => {
      const progress = loadFromStorage(movieId);

      if (progress && progress.position > minResumeSeconds && isFinite(progress.duration) && progress.duration > 0) {
        setSavedProgress(progress);
        setShowResumePrompt(true);
        setHasResumed(false);
        if (videoRef.current) {
          videoRef.current.pause();
        }
      } else {
        setSavedProgress(null);
        setShowResumePrompt(false);
        setHasResumed(false);
      }
    };

    // Use microtask to avoid synchronous setState in effect
    queueMicrotask(applyProgress);
  }, [movieId, minResumeSeconds, clearSaveTimer]);

  const resumeFromSaved = useCallback(() => {
    if (savedProgress && videoRef.current) {
      videoRef.current.currentTime = savedProgress.position;
      videoRef.current.play().catch(() => {});
    }
    setShowResumePrompt(false);
    setHasResumed(true);
  }, [savedProgress, videoRef]);

  const startFromBeginning = useCallback(() => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {});
    }
    setShowResumePrompt(false);
    setHasResumed(true);
  }, [videoRef]);

  // Attach video event listeners
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !movieId) return;

    const onPlay = () => startSaveTimer();
    const onPause = () => {
      clearSaveTimer();
      saveToServerAndStorage();
    };
    const onEnded = () => {
      clearSaveTimer();
      const mid = movieIdRef.current;
      const eid = episodeIdRef.current;
      if (mid) {
        removeFromStorage(mid);
        saveToServer(mid, eid, 100);
      }
    };
    const onSeeked = () => saveCurrentPosition();

    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('ended', onEnded);
    video.addEventListener('seeked', onSeeked);

    return () => {
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('ended', onEnded);
      video.removeEventListener('seeked', onSeeked);
      clearSaveTimer();
      saveToServerAndStorage();
    };
  }, [videoRef, movieId, startSaveTimer, clearSaveTimer, saveCurrentPosition, saveToServerAndStorage]);

  return {
    savedProgress,
    showResumePrompt,
    hasResumed,
    resumeFromSaved,
    startFromBeginning,
    formatTime,
  };
}