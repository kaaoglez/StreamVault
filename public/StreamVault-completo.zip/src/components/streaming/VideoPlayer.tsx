'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  ArrowLeft,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  SkipForward,
  SkipBack,
  ChevronRight,
  List,
  RotateCcw,
  Loader2,
  AlertTriangle,
  Zap,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAppStore, type Movie, type Episode } from '@/store/app-store';
import { useVideoProgress } from '@/hooks/useVideoProgress';

// ─── Types ───────────────────────────────────────────────────────

interface EpisodeWithSeason extends Episode {
  seasonNumber: number;
}

interface PlayerContentProps {
  playingMovie: Movie;
  playingEpisode: Episode | null;
  closePlayer: () => void;
}

// ─── Format helpers ──────────────────────────────────────────────

function formatTime(seconds: number): string {
  if (!isFinite(seconds) || seconds < 0) return '0:00';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) {
    return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }
  return `${m}:${s.toString().padStart(2, '0')}`;
}

// Browser-native container formats
const BROWSER_NATIVE_EXTS = new Set(['mp4', 'webm', 'ogv', 'm4v']);

// Clearly non-native that skip native attempt entirely
const NON_NATIVE_EXTS = new Set(['mkv', 'avi', 'wmv', 'flv', 'mov', 'mpg', 'mpeg', '3gp', 'ts', 'm2ts', 'mts']);

// Detect HEVC/H.265 in filename (like the reference repo's MoviesSection does)
function isHevcFile(filename: string): boolean {
  const lower = filename.toLowerCase();
  return /hevc|h\.?265|x265|10[-_]?bit/.test(lower);
}

// ─── Main VideoPlayer ────────────────────────────────────────────

export function VideoPlayer() {
  const { isPlayerOpen, playingMovie, playingEpisode, closePlayer } =
    useAppStore();

  if (!isPlayerOpen || !playingMovie) return null;

  return (
    <AnimatePresence mode="wait">
      <PlayerContent
        key={playingMovie.id + (playingEpisode?.id ?? '')}
        playingMovie={playingMovie}
        playingEpisode={playingEpisode}
        closePlayer={closePlayer}
      />
    </AnimatePresence>
  );
}

// ─── Player Content ──────────────────────────────────────────────

function PlayerContent({
  playingMovie,
  playingEpisode,
  closePlayer,
}: PlayerContentProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const nextEpisodeTimerRef = useRef<NodeJS.Timeout | null>(null);
  const progressSaveTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showEpisodeList, setShowEpisodeList] = useState(false);
  const [showNextEpisode, setShowNextEpisode] = useState(false);
  const [nextEpisodeCountdown, setNextEpisodeCountdown] = useState(10);
  const [episodes, setEpisodes] = useState<EpisodeWithSeason[]>([]);
  const [buffered, setBuffered] = useState(0);
  const [videoError, setVideoError] = useState<string | null>(null);
  const [needsFfmpeg, setNeedsFfmpeg] = useState(false);
  const [isTranscoding, setIsTranscoding] = useState(false);
  const [errorType, setErrorType] = useState<'format' | 'rateLimit' | 'network' | 'ffmpeg'>('format');

  // ─── Fallback state using REFS (not state) to avoid re-render loops ───
  // This is exactly how the reference repo does it with Artplayer
  const currentModeRef = useRef<'native' | 'transcode'>('native');
  const hasTriedNativeRef = useRef(false);
  const hasTriedTranscodeRef = useRef(false);
  const retryCountRef = useRef(0);

  const { openPlayer } = useAppStore();

  // ─── Determine video source ─────────────────────────────────
  const videoId = playingEpisode?.filePath
    ? playingEpisode.id
    : playingMovie.filePath
      ? playingMovie.id
      : null;

  const progressKey = playingEpisode
    ? `${playingMovie.id}:${playingEpisode.id}`
    : playingMovie.id;

  const filePath = playingEpisode?.filePath || playingMovie.filePath || '';
  const fileExt = filePath.split('.').pop()?.toLowerCase() || '';
  const fileName = filePath.split(/[\\/]/).pop() || '';

  // Determine initial mode
  const isHevc = isHevcFile(fileName);
  const isClearlyNonNative = NON_NATIVE_EXTS.has(fileExt);
  const initialTranscode = isClearlyNonNative || (BROWSER_NATIVE_EXTS.has(fileExt) && isHevc);

  // ─── Video URL construction ─────────────────────────────────
  const videoBaseUrl = videoId ? `/api/video/${videoId}` : null;
  const hasVideo = !!videoBaseUrl || !!playingEpisode?.videoUrl || !!playingMovie.videoUrl;
  const isSeries = playingMovie.type === 'series';

  // ─── Build URL based on current mode ────────────────────────
  const buildUrl = useCallback((mode: 'native' | 'transcode') => {
    if (!videoBaseUrl) return playingEpisode?.videoUrl || playingMovie.videoUrl || '';
    return mode === 'transcode'
      ? `${videoBaseUrl}?transcode=true`
      : videoBaseUrl;
  }, [videoBaseUrl, playingEpisode?.videoUrl, playingMovie.videoUrl]);

  // ─── Video Progress Hook ──────────────────────────────────
  const {
    savedProgress,
    showResumePrompt,
    resumeFromSaved,
    startFromBeginning,
    formatTime: formatProgressTime,
  } = useVideoProgress({
    videoPath: filePath || null,
    videoRef,
    movieId: progressKey,
    episodeId: playingEpisode?.id || null,
    minResumeSeconds: 30,
    saveInterval: 5,
  });

  // ─── PROPER STREAM ABORT (from reference repo's destroyArt) ────
  // This is THE critical pattern: remove src + load() forces browser
  // to abort the HTTP connection, which triggers server-side request.signal
  // abort, which kills FFmpeg and frees the transcode slot.
  const abortCurrentStream = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    try {
      video.pause();
      video.removeAttribute('src');
      video.load(); // Forces browser to abort the in-flight HTTP request
    } catch { /* ignore */ }
    // Clear progress save timer
    if (progressSaveTimerRef.current) {
      clearInterval(progressSaveTimerRef.current);
      progressSaveTimerRef.current = null;
    }
  }, []);

  // ─── Initialize video source ───────────────────────────────
  // This runs once on mount (component remounts via key prop)
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !hasVideo) return;

    // Reset all refs for a fresh start
    hasTriedNativeRef.current = false;
    hasTriedTranscodeRef.current = false;
    retryCountRef.current = 0;

    // Determine initial mode
    if (initialTranscode) {
      currentModeRef.current = 'transcode';
      hasTriedNativeRef.current = true; // Skip native for clearly non-native
    } else {
      currentModeRef.current = 'native';
    }

    const url = buildUrl(currentModeRef.current);
    video.src = url;
    video.volume = volume;
    video.load();

    // Auto-play (will be blocked if user hasn't interacted, that's fine)
    const tryAutoPlay = () => {
      video.play().catch(() => {});
    };
    video.addEventListener('canplay', tryAutoPlay, { once: true });
    if (video.readyState >= 3) tryAutoPlay();

    return () => {
      video.removeEventListener('canplay', tryAutoPlay);
    };
  }, []); // Only run on mount

  // ─── Switch to transcode mode (THE critical fallback) ──────
  // Pattern from reference repo's switchToTranscode()
  const switchToTranscode = useCallback(() => {
    if (hasTriedTranscodeRef.current) return; // Guard: only switch once

    const video = videoRef.current;
    if (!video) return;

    console.log(`[PLAYER] Switching to transcode for ${fileExt}`);

    // 1. Abort the current stream (closes HTTP connection → kills server FFmpeg)
    abortCurrentStream();

    // 2. Update refs
    hasTriedTranscodeRef.current = true;
    currentModeRef.current = 'transcode';
    retryCountRef.current++;

    // 3. Set new source and load
    const url = buildUrl('transcode');
    video.src = url;
    setIsTranscoding(true);
    setVideoError(null);
    setNeedsFfmpeg(false);
    video.load();
    video.play().catch(() => {});
  }, [fileExt, buildUrl, abortCurrentStream]);

  // ─── Handle video error with proper error code detection ───
  // This is how the reference repo handles art.on('video:error')
  const handleVideoError = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    const vError = video.error;
    const errorCode = vError?.code || 0;

    console.log(`[PLAYER] Video error code: ${errorCode}, mode: ${currentModeRef.current}`);

    // Error 1 = MEDIA_ERR_ABORTED — user action or cleanup, ignore silently
    if (errorCode === 1) return;

    // Error 2 = MEDIA_ERR_NETWORK
    if (errorCode === 2) {
      setErrorType('network');
      setVideoError('Error de red. Verifica que el archivo sea accesible.');
      return;
    }

    // Error 3 = MEDIA_ERR_DECODE (codec not supported even in valid container)
    // Error 4 = MEDIA_ERR_SRC_NOT_SUPPORTED (format/container not supported)
    if (errorCode === 3 || errorCode === 4) {
      if (currentModeRef.current === 'native' && !hasTriedTranscodeRef.current) {
        // AUTO-FALLBACK: try transcode!
        switchToTranscode();
        return;
      }
      // Already tried transcode or started in transcode mode
      setErrorType('format');
      setVideoError('No se pudo reproducir el video. El formato o codec no es compatible.');
      return;
    }

    // Unknown error — try to check if it's a 422 (needs ffmpeg)
    const currentUrl = video.src;
    if (currentUrl) {
      fetch(currentUrl, { method: 'HEAD' })
        .then(r => {
          if (r.status === 422) return r.json();
          return null;
        })
        .then(data => {
          if (data?.needsFfmpeg) {
            setErrorType('ffmpeg');
            setNeedsFfmpeg(true);
            setVideoError(`Formato .${(data.format || fileExt).replace('.', '').toUpperCase()} requiere ffmpeg.`);
          } else if (currentModeRef.current === 'native' && !hasTriedTranscodeRef.current) {
            switchToTranscode();
          } else {
            setErrorType('format');
            setVideoError('No se pudo cargar el video.');
          }
        })
        .catch(() => {
          setErrorType('network');
          setVideoError('No se pudo cargar el video. Verifica que el archivo exista.');
        });
    }
  }, [fileExt, switchToTranscode]);

  // ─── Manual retry button ───────────────────────────────────
  const handleRetry = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    abortCurrentStream();
    hasTriedNativeRef.current = true; // Skip native, go straight to transcode
    currentModeRef.current = 'transcode';
    retryCountRef.current++;

    const url = buildUrl('transcode');
    video.src = url;
    setVideoError(null);
    setNeedsFfmpeg(false);
    setIsTranscoding(true);
    video.load();
    video.play().catch(() => {});
  }, [buildUrl, abortCurrentStream]);

  // ─── Fetch episodes for series ─────────────────────────────────
  useEffect(() => {
    if (!isSeries) return;
    fetch(`/api/movies/${playingMovie.id}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.episodes) setEpisodes(data.episodes);
      })
      .catch(() => {});
  }, [isSeries, playingMovie.id]);

  // ─── Current episode index ────────────────────────────────────
  const currentEpisodeIndex = playingEpisode
    ? episodes.findIndex(
        (ep) =>
          ep.seasonNumber === playingEpisode.seasonNumber &&
          ep.episodeNumber === playingEpisode.episodeNumber
      )
    : -1;

  const nextEpisode =
    currentEpisodeIndex >= 0 && currentEpisodeIndex < episodes.length - 1
      ? episodes[currentEpisodeIndex + 1]
      : null;

  // ─── Show next episode when video ends ────────────────────────
  const handleVideoEnd = useCallback(() => {
    setIsPlaying(false);
    if (nextEpisode) {
      setShowNextEpisode(true);
      setNextEpisodeCountdown(10);
    }
  }, [nextEpisode]);

  // ─── Next episode countdown ────────────────────────────────────
  useEffect(() => {
    if (!showNextEpisode || !nextEpisode) return;

    nextEpisodeTimerRef.current = setInterval(() => {
      setNextEpisodeCountdown((prev) => {
        if (prev <= 1) {
          openPlayer(playingMovie, nextEpisode);
          return 10;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (nextEpisodeTimerRef.current) clearInterval(nextEpisodeTimerRef.current);
    };
  }, [showNextEpisode, nextEpisode, openPlayer, playingMovie]);

  // ─── Lock scroll + cleanup on unmount ─────────────────────────
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
      if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
      if (nextEpisodeTimerRef.current) clearInterval(nextEpisodeTimerRef.current);
      if (progressSaveTimerRef.current) clearInterval(progressSaveTimerRef.current);
      // CRITICAL: abort stream on unmount to free server resources
      abortCurrentStream();
    };
  }, [abortCurrentStream]);

  // ─── Auto-hide controls ────────────────────────────────────────
  const resetControlsTimeout = useCallback(() => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  }, [isPlaying]);

  // ─── Video event handlers ──────────────────────────────────────
  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
      const video = videoRef.current;
      if (video.buffered.length > 0) {
        setBuffered(video.buffered.end(video.buffered.length - 1));
      }
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };

  const togglePlay = () => {
    if (!videoRef.current || !hasVideo) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const handleSkip = (seconds: number) => {
    if (videoRef.current) videoRef.current.currentTime += seconds;
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !videoRef.current.muted;
      setIsMuted(!isMuted);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.volume = vol;
      setVolume(vol);
      setIsMuted(vol === 0);
    }
  };

  const toggleFullscreen = async () => {
    if (!containerRef.current) return;
    try {
      if (!document.fullscreenElement) {
        await containerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch {}
  };

  useEffect(() => {
    const handleFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // ─── Keyboard shortcuts ────────────────────────────────────────
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (showNextEpisode || showResumePrompt) return;
      switch (e.key) {
        case ' ':
        case 'k':
          e.preventDefault();
          togglePlay();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          handleSkip(-10);
          break;
        case 'ArrowRight':
          e.preventDefault();
          handleSkip(10);
          break;
        case 'ArrowUp':
          e.preventDefault();
          if (videoRef.current) {
            const newVol = Math.min(1, videoRef.current.volume + 0.1);
            videoRef.current.volume = newVol;
            setVolume(newVol);
          }
          break;
        case 'ArrowDown':
          e.preventDefault();
          if (videoRef.current) {
            const newVol = Math.max(0, videoRef.current.volume - 0.1);
            videoRef.current.volume = newVol;
            setVolume(newVol);
          }
          break;
        case 'f':
          e.preventDefault();
          toggleFullscreen();
          break;
        case 'm':
          e.preventDefault();
          toggleMute();
          break;
        case 'Escape':
          if (!isFullscreen) closePlayer();
          break;
      }
      resetControlsTimeout();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [togglePlay, handleSkip, toggleFullscreen, toggleMute, closePlayer, isFullscreen, showNextEpisode, showResumePrompt, resetControlsTimeout]);

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;
  const bufferedProgress = duration > 0 ? (buffered / duration) * 100 : 0;

  const playNextEpisode = () => {
    if (nextEpisode) {
      setShowNextEpisode(false);
      openPlayer(playingMovie, nextEpisode);
    }
  };

  // ─── Render ────────────────────────────────────────────────────
  return (
    <motion.div
      ref={containerRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black select-none"
      style={{ cursor: showControls ? 'default' : 'none' }}
      onMouseMove={resetControlsTimeout}
      onClick={(e) => {
        if ((e.target as HTMLElement).tagName !== 'INPUT' && (e.target as HTMLElement).tagName !== 'BUTTON') {
          resetControlsTimeout();
        }
      }}
    >
      {/* Transcoding indicator */}
      {hasVideo && isTranscoding && !videoError && !needsFfmpeg && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/60 pointer-events-none">
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="h-10 w-10 text-amber-400 animate-spin" />
            <p className="text-white text-sm font-medium">Transcodificando video</p>
            <p className="text-white/50 text-xs">
              Convirtiendo {fileExt.toUpperCase()} a formato compatible...
            </p>
          </div>
        </div>
      )}

      {/* FFmpeg missing error */}
      {needsFfmpeg && (
        <div className="absolute inset-0 flex items-center justify-center z-10 bg-black/60">
          <div className="bg-[#1a1a1a] border border-red-800 rounded-xl px-8 py-6 text-center max-w-md mx-4">
            <AlertTriangle className="h-10 w-10 text-red-400 mx-auto mb-3" />
            <p className="text-white text-sm font-medium mb-2">FFmpeg no encontrado</p>
            <p className="text-gray-400 text-xs mb-4">
              Los archivos .{fileExt.toUpperCase()} necesitan ffmpeg para transcodificar al vuelo.
            </p>
            <a
              href="https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 bg-[#e50914] hover:bg-[#c40812] text-white text-sm px-4 py-2 rounded-lg transition-colors"
            >
              Descargar FFmpeg (Windows)
            </a>
            <p className="text-gray-600 text-xs mt-3">
              Instala y agrega ffmpeg.exe al PATH del sistema, luego reinicia StreamVault.
            </p>
          </div>
        </div>
      )}

      {/* Video load error */}
      {videoError && !needsFfmpeg && (
        <div className="absolute inset-0 flex items-center justify-center z-10 bg-black/70">
          <div className="bg-[#1a1a1a] border border-white/10 rounded-xl px-8 py-6 text-center max-w-md mx-4">
            <p className="text-red-300 text-sm font-medium mb-1">Error de reproducción</p>
            <p className="text-gray-400 text-xs mb-5">{videoError}</p>
            <div className="flex gap-3 justify-center">
              {errorType !== 'rateLimit' && (
                <Button
                  className="bg-[#e50914] hover:bg-[#c40812] text-white"
                  onClick={handleRetry}
                >
                  <Zap className="h-4 w-4 mr-2" />
                  Reintentar
                </Button>
              )}
              <Button
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10"
                onClick={closePlayer}
              >
                <X className="h-4 w-4 mr-2" />
                Cerrar
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Resume Prompt */}
      {showResumePrompt && savedProgress && (
        <div className="absolute inset-0 flex items-center justify-center z-[15] bg-black/40 backdrop-blur-sm">
          <div className="bg-[#181818] border border-white/15 rounded-2xl p-6 max-w-sm w-full mx-4 shadow-2xl">
            <p className="text-white font-medium text-center mb-1">¿Continuar viendo?</p>
            <p className="text-gray-400 text-xs text-center mb-5">
              Te quedaste en {formatProgressTime(savedProgress.position)} de {formatProgressTime(savedProgress.duration)}
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1 bg-white/10 border-white/20 text-white hover:bg-white/20 hover:text-white"
                onClick={startFromBeginning}
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                Desde el inicio
              </Button>
              <Button
                className="flex-1 bg-[#e50914] hover:bg-[#c40812] text-white"
                onClick={resumeFromSaved}
              >
                <Play className="h-4 w-4 mr-2 fill-white" />
                Continuar
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Video Element — NO key prop! We manipulate src directly */}
      {hasVideo && (
        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={() => {
            setVideoError(null);
            if (videoRef.current) {
              setDuration(videoRef.current.duration);
              videoRef.current.volume = volume;
            }
          }}
          onEnded={handleVideoEnd}
          onPlay={() => { setIsPlaying(true); setVideoError(null); setIsTranscoding(false); }}
          onPause={() => setIsPlaying(false)}
          onCanPlay={() => { setVideoError(null); setNeedsFfmpeg(false); setIsTranscoding(false); }}
          onError={handleVideoError}
          playsInline
        />
      )}

      {!hasVideo && (
        <div className="absolute inset-0 flex items-center justify-center">
          <img
            src={playingMovie.backdropImage}
            alt=""
            className="w-full h-full object-cover opacity-30 blur-sm"
            onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
          />
          <div className="absolute inset-0 bg-black/50" />
          <div className="relative z-10 text-center px-8">
            <Play className="h-16 w-16 text-white/40 mx-auto mb-4" />
            <p className="text-white/60 text-lg">
              {isSeries && playingEpisode
                ? `${playingMovie.title} - ${playingEpisode.title}`
                : playingMovie.title}
            </p>
            <p className="text-white/30 text-sm mt-2">Sin video disponible.</p>
          </div>
        </div>
      )}

      {/* ─── Controls Overlay ──────────────────────────────────── */}
      <AnimatePresence>
        {showControls && !showNextEpisode && !showResumePrompt && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 z-10"
          >
            {/* Top Bar */}
            <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/80 via-black/40 to-transparent px-4 md:px-8 pt-3 pb-12">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 h-9 w-9" onClick={closePlayer} aria-label="Volver">
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                  <div className="min-w-0">
                    <h2 className="text-white text-sm md:text-base font-medium truncate max-w-[50vw] md:max-w-[60vw]">
                      {playingMovie.title}
                    </h2>
                    {playingEpisode && (
                      <p className="text-gray-400 text-xs truncate">
                        T{playingEpisode.seasonNumber}:E{playingEpisode.episodeNumber} - {playingEpisode.title}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {isSeries && episodes.length > 0 && (
                    <Button variant="ghost" size="icon" className={`text-white hover:bg-white/10 h-9 w-9 ${showEpisodeList ? 'bg-white/20' : ''}`} onClick={() => setShowEpisodeList(!showEpisodeList)} aria-label="Lista de episodios">
                      <List className="h-5 w-5" />
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 h-9 w-9" onClick={closePlayer} aria-label="Cerrar">
                    <X className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Center Play Button */}
            {!isPlaying && hasVideo && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <button
                  className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-sm flex items-center justify-center transition-all pointer-events-auto"
                  onClick={(e) => { e.stopPropagation(); togglePlay(); }}
                  aria-label="Reproducir"
                >
                  <Play className="h-7 w-7 md:h-9 md:w-9 text-white ml-1 fill-white" />
                </button>
              </div>
            )}

            {/* Bottom Controls */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent px-4 md:px-8 pb-4 pt-16">
              {/* Progress Bar */}
              <div className="group/progress mb-3 relative h-6 flex items-center">
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-white/20 rounded-full overflow-hidden">
                  <div className="h-full bg-white/30 rounded-full" style={{ width: `${bufferedProgress}%` }} />
                </div>
                <input type="range" min={0} max={duration || 0} step={0.1} value={currentTime} onChange={handleSeek} className="absolute left-0 w-full h-1 opacity-0 cursor-pointer z-10" style={{ height: '20px', marginTop: '-8px' }} />
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-white/20 rounded-full overflow-hidden pointer-events-none">
                  <div className="h-full bg-[#e50914] rounded-full transition-[width] duration-100" style={{ width: `${progress}%` }} />
                  <div className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-[#e50914] rounded-full shadow-lg opacity-0 group-hover/progress:opacity-100 transition-opacity" style={{ left: `calc(${progress}% - 6px)` }} />
                </div>
              </div>

              {/* Control Buttons */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 md:gap-2">
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 h-9 w-9" onClick={() => handleSkip(-10)} aria-label="Retroceder 10s">
                    <SkipBack className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 h-10 w-10" onClick={togglePlay} aria-label={isPlaying ? 'Pausar' : 'Reproducir'}>
                    {isPlaying ? <Pause className="h-5 w-5 fill-white" /> : <Play className="h-5 w-5 ml-0.5 fill-white" />}
                  </Button>
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 h-9 w-9" onClick={() => handleSkip(10)} aria-label="Adelantar 10s">
                    <SkipForward className="h-4 w-4" />
                  </Button>

                  <div className="hidden sm:flex items-center gap-1 ml-2">
                    <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 h-9 w-9" onClick={toggleMute} aria-label={isMuted ? 'Activar sonido' : 'Silenciar'}>
                      {isMuted || volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                    </Button>
                    <div className="relative w-20 h-6 flex items-center">
                      <input type="range" min={0} max={1} step={0.05} value={isMuted ? 0 : volume} onChange={handleVolumeChange} className="absolute w-full h-1 accent-white cursor-pointer" />
                    </div>
                  </div>

                  <span className="text-white/70 text-xs ml-3 tabular-nums">
                    {formatTime(currentTime)} / {formatTime(duration)}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  {nextEpisode && (
                    <Button variant="ghost" size="sm" className="text-white hover:bg-white/10 h-9 px-2 gap-1 text-xs" onClick={playNextEpisode}>
                      <SkipForward className="h-4 w-4" />
                      <span className="hidden md:inline">Siguiente</span>
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 h-9 w-9" onClick={toggleFullscreen} aria-label={isFullscreen ? 'Salir de pantalla completa' : 'Pantalla completa'}>
                    {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
            </div>

            {/* ─── Episode List Sidebar ──────────────────────────── */}
            {showEpisodeList && isSeries && (
              <>
              <div className="absolute inset-0 z-10" onClick={() => setShowEpisodeList(false)} />
              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                className="absolute top-0 right-0 bottom-0 w-80 max-w-[85vw] bg-[#181818]/95 backdrop-blur-md border-l border-white/10 overflow-y-auto no-scrollbar z-20"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-white font-semibold text-lg">Episodios</h3>
                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white h-8 w-8" onClick={() => setShowEpisodeList(false)} aria-label="Cerrar lista">
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="space-y-1">
                    {episodes.map((ep, idx) => {
                      const isCurrent = playingEpisode && ep.seasonNumber === playingEpisode.seasonNumber && ep.episodeNumber === playingEpisode.episodeNumber;
                      return (
                        <button
                          key={ep.id}
                          className={`w-full flex items-start gap-3 p-3 rounded-lg transition-colors text-left group ${isCurrent ? 'bg-white/15' : 'hover:bg-white/10'}`}
                          onClick={() => { openPlayer(playingMovie, ep); setShowEpisodeList(false); }}
                        >
                          <span className="text-lg font-bold text-gray-500 w-7 text-center shrink-0 pt-0.5">{idx + 1}</span>
                          <div className="flex-1 min-w-0">
                            <p className={`text-sm font-medium truncate ${isCurrent ? 'text-[#e50914]' : 'text-white'}`}>{ep.title}</p>
                            <p className="text-xs text-gray-500 mt-0.5">T{ep.seasonNumber}:E{ep.episodeNumber}{ep.duration && ` · ${ep.duration}`}</p>
                            {ep.description && <p className="text-xs text-gray-500 mt-1 line-clamp-2">{ep.description}</p>}
                          </div>
                          {isCurrent && <div className="shrink-0 mt-1"><div className="w-2 h-2 rounded-full bg-[#e50914] animate-pulse" /></div>}
                          {!isCurrent && <ChevronRight className="h-4 w-4 text-gray-600 group-hover:text-white shrink-0 mt-1 transition-colors" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </motion.div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Next Episode Overlay ────────────────────────────── */}
      <AnimatePresence>
        {showNextEpisode && nextEpisode && (
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 40 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="absolute bottom-0 left-0 right-0 z-20"
          >
            <div className="absolute inset-0 -top-32" onClick={() => { setShowNextEpisode(false); if (nextEpisodeTimerRef.current) clearInterval(nextEpisodeTimerRef.current); }} />
            <div className="relative mx-auto max-w-3xl px-4 mb-8">
              <div className="bg-[#181818]/95 backdrop-blur-md rounded-xl border border-white/10 overflow-hidden shadow-2xl">
                <div className="flex items-center">
                  {nextEpisode.stillImage && (
                    <div className="hidden sm:block w-40 h-24 shrink-0">
                      <img src={nextEpisode.stillImage} alt={nextEpisode.title} className="w-full h-full object-cover" />
                    </div>
                  )}
                  <div className="flex-1 p-4">
                    <p className="text-gray-400 text-xs font-medium uppercase tracking-wider mb-1">Siguiente episodio</p>
                    <h4 className="text-white font-semibold text-sm md:text-base truncate">
                      T{nextEpisode.seasonNumber}:E{nextEpisode.episodeNumber} - {nextEpisode.title}
                    </h4>
                    {nextEpisode.duration && <p className="text-gray-500 text-xs mt-0.5">{nextEpisode.duration}</p>}
                  </div>
                  <button className="shrink-0 m-4 w-12 h-12 rounded-full bg-[#e50914] hover:bg-[#f40612] flex items-center justify-center transition-colors" onClick={playNextEpisode} aria-label="Reproducir siguiente episodio">
                    <SkipForward className="h-5 w-5 text-white fill-white" />
                  </button>
                </div>
                <div className="h-1 bg-white/10">
                  <div className="h-full bg-[#e50914] transition-all duration-1000 ease-linear" style={{ width: `${(nextEpisodeCountdown / 10) * 100}%` }} />
                </div>
              </div>
              <p className="text-center text-gray-500 text-xs mt-2">
                Reproduciendo automáticamente en {nextEpisodeCountdown}s · Presiona Esc para cancelar
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}