import { NextResponse } from 'next/server'
import { scanMultipleSeriesFolders, scanMultipleMovieFolders, type ParsedSeriesGroup, type ParsedMovieGroup, isSeasonFolder, extractSeasonFromFolder, extractYearFromFolderName, cleanTitle, cleanSeriesFolderName } from '@/lib/scanner'
import { searchMovie, searchSeries, getMovieDetails, getSeasonEpisodes, isRateLimited, resetRateLimit } from '@/lib/omdb'
import { getConfig } from '@/lib/config'
import { db } from '@/lib/db'

// ─── Shared types ────────────────────────────────────────────────

interface ScanProgress {
  phase: 'scanning' | 'fetching' | 'done' | 'error'
  current: number
  total: number
  title: string
  message: string
  found: number
  matched: number
  failed: number
  errors: string[]
  rateLimited: boolean
  debugSample?: string[]
}

let scanStatus: ScanProgress | null = null

// ─── GET: poll scan status ───────────────────────────────────────

export async function GET() {
  return NextResponse.json({
    scanning: scanStatus !== null && scanStatus.phase !== 'done' && scanStatus.phase !== 'error',
    progress: scanStatus,
  })
}

// ─── POST: two actions ───────────────────────────────────────────
//   ?action=import   → scan HD, store in DB (NO OMDB needed)
//   ?action=enrich   → enrich existing DB entries with OMDB data
//   (default, no action) → legacy: scan + OMDB in one step

export async function POST(request: Request) {
  const url = new URL(request.url)
  const action = url.searchParams.get('action')

  if (action === 'import') {
    return handleImport()
  }
  if (action === 'enrich') {
    return handleEnrich()
  }

  // Legacy: scan + OMDB in one step
  return handleLegacyScan()
}

// ─── ACTION 1: Import from HD → DB (no OMDB) ─────────────────────

async function handleImport() {
  try {
    const config = getConfig()
    const hasMovies = config.moviesFolders.some(f => f.trim())
    const hasSeries = config.seriesFolders.some(f => f.trim())

    if (!hasMovies && !hasSeries) {
      return NextResponse.json({ error: 'No hay carpetas configuradas' }, { status: 400 })
    }

    // Run import in background
    runImport(config.moviesFolders, config.seriesFolders).catch(err => {
      console.error('Import failed:', err)
    })

    return NextResponse.json({ success: true, message: 'Importación desde HD iniciada' })
  } catch (error) {
    scanStatus = null
    return NextResponse.json({ error: String(error) }, { status: 500 })
  }
}

async function runImport(moviesFolders: string[], seriesFolders: string[]) {
  const errors: string[] = []
  let found = 0

  try {
    scanStatus = {
      phase: 'scanning', current: 0, total: 0, title: '', message: 'Escaneando carpetas desde HD...',
      found: 0, matched: 0, failed: 0, errors: [], rateLimited: false,
    }

    // ── Scan movies by folder structure ──
    const movieGroups: ParsedMovieGroup[] = []
    for (const folder of moviesFolders) {
      if (!folder.trim()) continue
      try {
        const groups = await scanMultipleMovieFolders([folder])
        movieGroups.push(...groups)
      } catch (err) {
        errors.push(`Carpeta películas "${folder}": ${String(err)}`)
      }
    }

    // ── Scan series by folder structure ──
    const seriesGroups: ParsedSeriesGroup[] = []
    const seriesDebug: string[] = []
    for (const folder of seriesFolders) {
      if (!folder.trim()) continue
      try {
        const groups = await scanMultipleSeriesFolders([folder])
        seriesDebug.push(`Carpeta: ${folder} → ${groups.length} series encontradas`)
        groups.forEach(g => seriesDebug.push(`  ✓ "${g.seriesTitle}" (${g.episodes.length} eps)`))
        // Attach scanner debug log if available
        for (const g of groups) {
          if ((g as any)._debugLog) {
            seriesDebug.push(...(g as any)._debugLog)
          }
        }
        // If no groups found, try to get debug from last scan
        if (groups.length === 0) {
          seriesDebug.push(`  ⚠ No se encontraron series. Verifica que la carpeta contenga subcarpetas de series.`)
        }
        seriesGroups.push(...groups)
      } catch (err) {
        errors.push(`Carpeta series "${folder}": ${String(err)}`)
        seriesDebug.push(`  ✗ Error: ${String(err)}`)
      }
    }

    const totalSeriesEps = seriesGroups.reduce((sum, g) => sum + g.episodes.length, 0)
    const totalItems = movieGroups.length + seriesGroups.length
    found = movieGroups.length + totalSeriesEps

    scanStatus = {
      ...scanStatus!,
      total: totalItems, found,
      message: `Escaneado: ${movieGroups.length} películas, ${seriesGroups.length} series (${totalSeriesEps} episodios). Guardando en DB...`,
      debugSample: seriesDebug,
    }

    // ── Store movies in DB ──
    for (let i = 0; i < movieGroups.length; i++) {
      const group = movieGroups[i]
      scanStatus = {
        ...scanStatus!,
        current: i + 1,
        title: group.movieTitle,
        message: `Importando película ${i + 1}/${movieGroups.length}: ${group.movieTitle}`,
        errors: [...errors],
      }

      try {
        // Check if a movie with the same filePath already exists
        const existing = await db.movie.findFirst({
          where: {
            type: 'movie',
            filePath: group.files[0]?.filePath,
          },
        })

        if (!existing) {
          // Check if a movie with same title exists (avoid duplicates)
          const existingByTitle = await db.movie.findFirst({
            where: { title: group.movieTitle, type: 'movie' },
          })

          if (existingByTitle) {
            // Update filePath if we have one
            if (group.files[0]?.filePath) {
              await db.movie.update({
                where: { id: existingByTitle.id },
                data: { filePath: group.files[0]?.filePath || existingByTitle.filePath, local: true },
              })
            }
          } else {
            await db.movie.create({
              data: {
                title: group.movieTitle,
                description: '',
                coverImage: '/posters/default.svg',
                backdropImage: '/posters/default.svg',
                filePath: group.files[0]?.filePath || null,
                year: group.year || 2024,
                rating: 0,
                genre: 'Desconocido',
                type: 'movie',
                maturity: 'TV-MA',
                local: true,
              },
            })
          }
        }
      } catch (err) {
        errors.push(`Película "${group.movieTitle}": ${String(err)}`)
      }
    }

    // ── Store series in DB ──
    for (let i = 0; i < seriesGroups.length; i++) {
      const group = seriesGroups[i]
      scanStatus = {
        ...scanStatus!,
        current: movieGroups.length + i + 1,
        title: group.seriesTitle,
        message: `Importando serie ${i + 1}/${seriesGroups.length}: ${group.seriesTitle}`,
        errors: [...errors],
      }

      try {
        // Check if series with same title exists
        let series = await db.movie.findFirst({
          where: { title: group.seriesTitle, type: 'series' },
        })

        if (!series) {
          series = await db.movie.create({
            data: {
              title: group.seriesTitle,
              description: '',
              coverImage: '/posters/default.svg',
              backdropImage: '/posters/default.svg',
              year: group.year || 2024,
              rating: 0,
              genre: 'Desconocido',
              type: 'series',
              maturity: 'TV-MA',
              local: true,
            },
          })
        } else {
          // Update year if we have it
          if (group.year && (!series.year || series.year === 2024)) {
            await db.movie.update({ where: { id: series.id }, data: { year: group.year } })
          }
        }

        // Create episodes
        for (const ep of group.episodes) {
          const existingEp = await db.episode.findFirst({
            where: {
              seriesId: series.id,
              seasonNumber: ep.season || 1,
              episodeNumber: ep.episode || 1,
              filePath: ep.filePath,
            },
          })
          if (!existingEp) {
            await db.episode.create({
              data: {
                seriesId: series.id,
                seasonNumber: ep.season || 1,
                episodeNumber: ep.episode || 1,
                title: `Episodio ${ep.episode || 1}`,
                filePath: ep.filePath,
              },
            })
          }
        }
      } catch (err) {
        errors.push(`Serie "${group.seriesTitle}": ${String(err)}`)
      }
    }

    scanStatus = {
      phase: 'done', current: totalItems, total: totalItems,
      title: '', message: `Importación completa: ${movieGroups.length} películas, ${seriesGroups.length} series (${totalSeriesEps} episodios). Ahora puedes certificar con OMDB.`,
      found, matched: 0, failed: 0, errors, rateLimited: false,
      debugSample: seriesDebug,
    }
  } catch (error) {
    scanStatus = {
      phase: 'error', current: 0, total: 0, title: '',
      message: `Error: ${String(error)}`,
      found, matched: 0, failed: 0, errors: [...errors, String(error)], rateLimited: false,
    }
  }
}

// ─── ACTION 2: Enrich existing DB entries with OMDB ──────────────

async function handleEnrich() {
  try {
    const config = getConfig()
    if (!config.omdbApiKey) {
      return NextResponse.json({ error: 'Configura la API key de OMDB primero' }, { status: 400 })
    }

    resetRateLimit()

    runEnrich(config.omdbApiKey).catch(err => {
      console.error('Enrich failed:', err)
    })

    return NextResponse.json({ success: true, message: 'Certificación con OMDB iniciada' })
  } catch (error) {
    scanStatus = null
    return NextResponse.json({ error: String(error) }, { status: 500 })
  }
}

async function runEnrich(apiKey: string) {
  const errors: string[] = []
  let found = 0
  let matched = 0
  let failed = 0

  try {
    // Get all local entries that need enrichment (no OMDB poster or empty genre)
    const movies = await db.movie.findMany({
      where: {
        local: true,
        OR: [
          { coverImage: '/posters/default.svg' },
          { genre: 'Desconocido' },
        ],
      },
    })

    found = movies.length

    scanStatus = {
      phase: 'fetching', current: 0, total: found,
      title: '', message: `Certificando ${found} títulos con OMDB...`,
      found, matched: 0, failed: 0, errors: [], rateLimited: false,
    }

    for (let i = 0; i < movies.length; i++) {
      const movie = movies[i]

      if (isRateLimited()) {
        errors.push(`Límite de OMDB alcanzado. Se certificaron ${matched} de ${found} títulos.`)
        break
      }

      scanStatus = {
        ...scanStatus!,
        current: i + 1,
        title: movie.title,
        message: `Certificando ${i + 1}/${found}: ${movie.title}`,
        matched, failed, errors: [...errors], rateLimited: false,
      }

      try {
        const isSeries = movie.type === 'series'
        const searchResult = isSeries
          ? await searchSeries(movie.title, movie.year || undefined, apiKey)
          : await searchMovie(movie.title, movie.year || undefined, apiKey)

        if (searchResult.rateLimited) {
          errors.push(`Límite de OMDB alcanzado. Se certificaron ${matched} de ${found} títulos.`)
          break
        }

        if (searchResult.result) {
          const sr = searchResult.result
          const poster = (sr.Poster && sr.Poster !== 'N/A')
            ? sr.Poster
            : movie.coverImage

          let description = movie.description
          let rating = movie.rating
          let year = movie.year
          let genre = movie.genre
          let maturity = movie.maturity
          let duration: string | null = movie.duration

          const details = await getMovieDetails(sr.imdbID, apiKey)
          if (details) {
            if (details.Plot && details.Plot !== 'N/A') description = details.Plot
            if (details.imdbRating && details.imdbRating !== 'N/A') rating = parseFloat(details.imdbRating) || 0
            if (details.Year) year = parseInt(details.Year) || year
            if (details.Genre && details.Genre !== 'N/A') genre = details.Genre
            if (details.Rated && details.Rated !== 'N/A') maturity = details.Rated
            if (details.Runtime && details.Runtime !== 'N/A') duration = details.Runtime
          }

          await db.movie.update({
            where: { id: movie.id },
            data: {
              title: sr.Title,
              description,
              coverImage: poster,
              backdropImage: poster,
              year, rating, genre, maturity, duration,
            },
          })

          // Fetch episode details for series
          if (isSeries && !isRateLimited()) {
            const episodes = await db.episode.findMany({
              where: { seriesId: movie.id },
              orderBy: [{ seasonNumber: 'asc' }, { episodeNumber: 'asc' }],
            })
            const seasons = new Set(episodes.map(e => e.seasonNumber))
            for (const seasonNum of seasons) {
              try {
                const omdbEps = await getSeasonEpisodes(sr.imdbID, seasonNum, apiKey)
                if (omdbEps) {
                  const seasonEps = episodes.filter(e => e.seasonNumber === seasonNum)
                  for (const ep of seasonEps) {
                    const omdbEp = omdbEps.find(e => parseInt(e.Episode, 10) === ep.episodeNumber)
                    if (omdbEp) {
                      await db.episode.update({
                        where: { id: ep.id },
                        data: {
                          title: omdbEp.Title || ep.title,
                          description: omdbEp.Plot && omdbEp.Plot !== 'N/A' ? omdbEp.Plot : ep.description,
                        },
                      })
                    }
                  }
                }
              } catch { /* skip season details */ }
            }
          }

          matched++
        } else {
          failed++
          if (failed <= 10) {
            const omdbErr = searchResult.error || 'sin respuesta'
            errors.push(`"${movie.title}" → ${omdbErr}`)
          }
        }
      } catch (err) {
        failed++
        errors.push(`"${movie.title}": ${String(err)}`)
      }

      await new Promise(r => setTimeout(r, 200))
    }

    const rateLimitedNow = isRateLimited()
    let msg: string
    if (rateLimitedNow) {
      msg = `Límite diario alcanzado. ${matched} certificados, ${failed} sin coincidencia. Vuelve mañana.`
    } else if (matched === 0) {
      msg = `${found} títulos en DB, 0 con datos de OMDB. Revisa errores.`
    } else {
      msg = `Certificación completa: ${matched} con datos OMDB, ${failed} sin coincidencia.`
    }

    scanStatus = {
      phase: 'done', current: movies.length, total: found,
      title: '', message: msg,
      found, matched, failed, errors, rateLimited: rateLimitedNow,
    }
  } catch (error) {
    scanStatus = {
      phase: 'error', current: 0, total: 0, title: '',
      message: `Error: ${String(error)}`,
      found, matched, failed, errors: [...errors, String(error)], rateLimited: false,
    }
  }
}

// ─── Legacy: scan + OMDB in one step (kept for compatibility) ─────

async function handleLegacyScan() {
  try {
    const config = getConfig()
    const hasMovies = config.moviesFolders.some(f => f.trim())
    const hasSeries = config.seriesFolders.some(f => f.trim())

    if (!hasMovies && !hasSeries) {
      return NextResponse.json({ error: 'No hay carpetas configuradas' }, { status: 400 })
    }
    if (!config.omdbApiKey) {
      return NextResponse.json({ error: 'No hay API key de OMDB' }, { status: 400 })
    }

    resetRateLimit()

    runLegacyScan(config.omdbApiKey, config.moviesFolders, config.seriesFolders).catch(err => {
      console.error('Scan failed:', err)
    })

    return NextResponse.json({ success: true, message: 'Escaneo iniciado' })
  } catch (error) {
    scanStatus = null
    return NextResponse.json({ error: String(error) }, { status: 500 })
  }
}

async function runLegacyScan(apiKey: string, moviesFolders: string[], seriesFolders: string[]) {
  const errors: string[] = []
  let found = 0
  let matched = 0
  let failed = 0
  const debugSample: string[] = []

  try {
    scanStatus = {
      phase: 'scanning', current: 0, total: 0, title: '', message: 'Escaneando carpetas...',
      found: 0, matched: 0, failed: 0, errors: [], rateLimited: false,
    }

    // Scan movies using folder-based detection
    const movieGroups: ParsedMovieGroup[] = []
    for (const folder of moviesFolders) {
      if (!folder.trim()) continue
      try {
        const groups = await scanMultipleMovieFolders([folder])
        movieGroups.push(...groups)
      } catch (err) {
        errors.push(`Carpeta "${folder}": ${String(err)}`)
      }
    }

    // Scan series using folder-based detection
    const seriesGroups: ParsedSeriesGroup[] = []
    for (const folder of seriesFolders) {
      if (!folder.trim()) continue
      try {
        const groups = await scanMultipleSeriesFolders([folder])
        seriesGroups.push(...groups)
      } catch (err) {
        errors.push(`Carpeta series "${folder}": ${String(err)}`)
      }
    }

    const totalSeriesEpisodes = seriesGroups.reduce((sum, g) => sum + g.episodes.length, 0)
    found = movieGroups.length + totalSeriesEpisodes

    scanStatus = {
      ...scanStatus!, total: found, found,
      message: `Encontrados: ${movieGroups.length} películas, ${seriesGroups.length} series (${totalSeriesEpisodes} episodios)`,
    }

    if (found === 0) {
      scanStatus = {
        phase: 'done', current: 0, total: 0, title: '',
        message: 'No se encontraron videos. Verifica las rutas.',
        found: 0, matched: 0, failed: 0, errors, rateLimited: false,
      }
      return
    }

    const totalItems = movieGroups.length + seriesGroups.length
    let processed = 0

    // ── Process movies ──
    scanStatus = { ...scanStatus!, phase: 'fetching', message: 'Buscando datos de películas...' }

    for (const group of movieGroups) {
      if (isRateLimited()) {
        errors.push(`Límite de OMDB alcanzado. Se procesaron ${matched} de ${found} archivos.`)
        break
      }

      const searchQuery = `"${group.movieTitle}"${group.year ? ` (${group.year})` : ''}`
      if (debugSample.length < 5) debugSample.push(searchQuery)

      scanStatus = {
        ...scanStatus!, current: processed + 1,
        title: group.movieTitle, message: `Buscando: ${searchQuery}`,
        matched, failed, errors: [...errors], rateLimited: false,
      }

      try {
        const searchResult = await searchMovie(group.movieTitle, group.year || undefined, apiKey)

        if (searchResult.rateLimited) {
          errors.push(`Límite de OMDB alcanzado.`)
          break
        }

        if (searchResult.result) {
          const sr = searchResult.result
          const poster = (sr.Poster && sr.Poster !== 'N/A')
            ? sr.Poster
            : '/posters/default.svg'

          let description = ''
          let rating = 0
          let year = group.year || parseInt(sr.Year) || 2024
          let genre = 'Drama'
          let duration: string | null = null
          let maturity = 'TV-MA'

          const details = await getMovieDetails(sr.imdbID, apiKey)
          if (details) {
            description = details.Plot && details.Plot !== 'N/A' ? details.Plot : ''
            rating = parseFloat(details.imdbRating) || 0
            year = parseInt(details.Year) || year
            genre = details.Genre && details.Genre !== 'N/A' ? details.Genre : 'Drama'
            duration = details.Runtime && details.Runtime !== 'N/A' ? details.Runtime : null
            maturity = details.Rated && details.Rated !== 'N/A' ? details.Rated : 'TV-MA'
          }

          matched++

          const existing = await db.movie.findFirst({ where: { title: sr.Title, type: 'movie' } })
          if (existing) {
            await db.movie.update({
              where: { id: existing.id },
              data: { filePath: group.files[0]?.filePath || existing.filePath, coverImage: poster, backdropImage: poster, local: true },
            })
          } else {
            await db.movie.create({
              data: {
                title: sr.Title, description, coverImage: poster, backdropImage: poster,
                filePath: group.files[0]?.filePath || null, year, rating, duration, genre,
                type: 'movie', maturity, local: true,
              },
            })
          }
        } else {
          failed++
          const omdbErr = searchResult.error || 'sin respuesta'
          if (failed <= 10) {
            errors.push(`${searchQuery} → ${omdbErr}`)
          }

          const existing = await db.movie.findFirst({ where: { title: group.movieTitle, type: 'movie' } })
          if (!existing) {
            await db.movie.create({
              data: {
                title: group.movieTitle, description: '',
                coverImage: '/posters/default.svg', backdropImage: '/posters/default.svg',
                filePath: group.files[0]?.filePath || null, year: group.year || 2024,
                rating: 0, genre: 'Desconocido', type: 'movie', local: true,
              },
            })
          }
        }
      } catch (err) {
        failed++
        errors.push(`"${group.movieTitle}": ${String(err)}`)
      }

      processed++
      await new Promise(r => setTimeout(r, 200))
    }

    // ── Process series ──
    for (const seriesGroup of seriesGroups) {
      const files = seriesGroup.episodes
      if (isRateLimited()) {
        errors.push(`Límite de OMDB alcanzado. Series restantes sin datos.`)
        break
      }

      scanStatus = {
        ...scanStatus!, current: processed + 1,
        title: seriesGroup.seriesTitle, message: `Buscando serie: ${seriesGroup.seriesTitle}`,
        matched, failed, errors: [...errors],
      }

      try {
        const searchResult = await searchSeries(seriesGroup.seriesTitle, seriesGroup.year || undefined, apiKey)

        if (searchResult.rateLimited) {
          errors.push(`Límite de OMDB alcanzado.`)
          break
        }

        if (searchResult.result) {
          const sr = searchResult.result
          const poster = (sr.Poster && sr.Poster !== 'N/A')
            ? sr.Poster
            : '/posters/default.svg'

          let description = ''
          let rating = 0
          let year = seriesGroup.year || parseInt(sr.Year) || 2024
          let genre = 'Drama'
          let maturity = 'TV-MA'

          const details = await getMovieDetails(sr.imdbID, apiKey)
          if (details) {
            description = details.Plot && details.Plot !== 'N/A' ? details.Plot : ''
            rating = parseFloat(details.imdbRating) || 0
            year = parseInt(details.Year) || year
            genre = details.Genre && details.Genre !== 'N/A' ? details.Genre : 'Drama'
            maturity = details.Rated && details.Rated !== 'N/A' ? details.Rated : 'TV-MA'
          }

          matched++

          let series = await db.movie.findFirst({ where: { title: sr.Title, type: 'series' } })
          if (series) {
            series = await db.movie.update({
              where: { id: series.id },
              data: { coverImage: poster, backdropImage: poster, local: true },
            })
          } else {
            series = await db.movie.create({
              data: {
                title: sr.Title, description, coverImage: poster, backdropImage: poster,
                year, rating, genre, type: 'series', maturity, local: true,
              },
            })
          }

          for (const file of files) {
            const seasonNum = file.season || 1
            const episodeNum = file.episode || 1

            const existingEp = await db.episode.findFirst({
              where: { seriesId: series.id, seasonNumber: seasonNum, episodeNumber: episodeNum },
            })

            if (!existingEp) {
              let epTitle = file.episode ? `Episodio ${file.episode}` : file.title
              let epDesc: string | null = null

              if (!isRateLimited()) {
                try {
                  const omdbEps = await getSeasonEpisodes(sr.imdbID, seasonNum, apiKey)
                  if (omdbEps) {
                    const omdbEp = omdbEps.find(e => parseInt(e.Episode, 10) === episodeNum)
                    if (omdbEp) {
                      epTitle = omdbEp.Title || epTitle
                      epDesc = omdbEp.Plot && omdbEp.Plot !== 'N/A' ? omdbEp.Plot : null
                    }
                  }
                } catch { /* skip */ }
              }

              await db.episode.create({
                data: {
                  seriesId: series.id, seasonNumber: seasonNum, episodeNumber: episodeNum,
                  title: epTitle, description: epDesc, filePath: file.filePath,
                },
              })
            }
          }
        } else {
          failed++
          const omdbErr = searchResult.error || 'sin respuesta'
          if (failed <= 10) {
            errors.push(`Serie "${seriesGroup.seriesTitle}" → ${omdbErr}`)
          }

          const existingSeries = await db.movie.findFirst({ where: { title: seriesGroup.seriesTitle, type: 'series' } })
          if (!existingSeries) {
            const series = await db.movie.create({
              data: {
                title: seriesGroup.seriesTitle, description: '',
                coverImage: '/posters/default.svg', backdropImage: '/posters/default.svg',
                year: seriesGroup.year || 2024, rating: 0, genre: 'Desconocido',
                type: 'series', local: true,
              },
            })
            for (const file of files) {
              await db.episode.create({
                data: {
                  seriesId: series.id, seasonNumber: file.season || 1,
                  episodeNumber: file.episode || 1, title: `Episodio ${file.episode || 1}`,
                  filePath: file.filePath,
                },
              })
            }
          }
        }
      } catch (err) {
        failed++
        errors.push(`Serie "${seriesGroup.seriesTitle}": ${String(err)}`)
      }

      processed++
      await new Promise(r => setTimeout(r, 200))
    }

    const rateLimitedNow = isRateLimited()
    let msg: string
    if (rateLimitedNow) {
      msg = `Límite diario de OMDB alcanzado. ${matched} con datos, ${failed} sin coincidencia. Vuelve mañana.`
    } else if (matched === 0) {
      msg = `${found} archivos encontrados, 0 con datos de OMDB.`
    } else {
      msg = `Listo! ${found} archivos → ${matched} con datos de OMDB, ${failed} sin coincidencia.`
    }

    scanStatus = {
      phase: 'done', current: processed, total: totalItems,
      title: '', message: msg,
      found, matched, failed, errors, rateLimited: rateLimitedNow,
      debugSample,
    }
  } catch (error) {
    scanStatus = {
      phase: 'error', current: 0, total: 0, title: '',
      message: `Error: ${String(error)}`,
      found, matched, failed, errors: [...errors, String(error)], rateLimited: false,
    }
  }
}

// ─── PATCH: Reorganize by folder structure ────────────────────────
//   ?type=series  → reorganize series (default)
//   ?type=movies  → reorganize movies
//   ?dryRun=1     → preview only

export async function PATCH(request: Request) {
  try {
    const url = new URL(request.url)
    const type = url.searchParams.get('type') || 'series'
    const dryRun = url.searchParams.get('dryRun') === '1'

    if (type === 'movies') {
      return handleReorganizeMovies(dryRun)
    }
    return handleReorganizeSeries(dryRun)
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 })
  }
}

// ─── Reorganize Series ────────────────────────────────────────────

async function handleReorganizeSeries(dryRun: boolean) {
  const allSeries = await db.movie.findMany({
    where: { type: 'series' },
    include: { episodes: true },
  })

  if (allSeries.length === 0) {
    return NextResponse.json({ success: false, message: 'No hay series en la base de datos. Primero importa desde HD.' })
  }

  const config = getConfig()
  const seriesFolders = (config.seriesFolders || []).filter(f => f.trim())

  if (seriesFolders.length === 0) {
    return NextResponse.json({ success: false, message: 'No hay carpetas de series configuradas.' })
  }

  // Collect all episodes
  interface EpData { id: string; seriesId: string; filePath: string }
  const allEps: EpData[] = []
  for (const s of allSeries) {
    for (const ep of s.episodes) {
      if (ep.filePath) {
        allEps.push({ id: ep.id, seriesId: s.id, filePath: ep.filePath })
      }
    }
  }

  if (allEps.length === 0) {
    return NextResponse.json({ success: false, message: 'No hay episodios con ruta de archivo. Primero importa desde HD.' })
  }

  // ── Path normalization ──
  function normalizePath(p: string): string {
    return p.replace(/\\/g, '/').replace(/\/+$/, '').toLowerCase()
  }

  function toSegments(p: string): string[] {
    return p.replace(/\\/g, '/').replace(/\/+$/, '').split('/').filter(Boolean)
  }

  // ── Pre-compute normalized roots (longest first) ──
  const roots = seriesFolders.map(f => {
    const trimmed = f.trim()
    const norm = normalizePath(trimmed)
    const segs = toSegments(trimmed)
    return { original: trimmed, normalized: norm, segmentCount: segs.length }
  }).sort((a, b) => b.normalized.length - a.normalized.length)

  function findRootSegments(filePath: string): { rootOriginal: string; segmentCount: number } | null {
    const normFile = normalizePath(filePath)
    for (const root of roots) {
      if (normFile === root.normalized || normFile.startsWith(root.normalized + '/')) {
        return { rootOriginal: root.original, segmentCount: root.segmentCount }
      }
    }
    return null
  }

  // ── Parse file path → series name, season ──
  const diagnostics: string[] = []
  const unmatchedSamples: string[] = []

  function parsePath(filePath: string): { seriesName: string; season: number; fileName: string; folderPath: string } | null {
    const allSegs = toSegments(filePath)
    const fileName = allSegs.pop()!

    const rootMatch = findRootSegments(filePath)
    if (!rootMatch) {
      if (unmatchedSamples.length < 5) unmatchedSamples.push(filePath)
      return null
    }

    const dirSegments = allSegs.slice(rootMatch.segmentCount)

    if (dirSegments.length === 0) {
      const name = cleanTitle(fileName.replace(/\.[^.]+$/, ''))
      return name ? { seriesName: name, season: 1, fileName, folderPath: allSegs.join('/') } : null
    }

    // Walk backwards, skip season folders
    let season = 1
    let seriesNameEnd = dirSegments.length - 1

    for (let i = dirSegments.length - 1; i >= 0; i--) {
      if (isSeasonFolder(dirSegments[i])) {
        season = extractSeasonFromFolder(dirSegments[i]) || 1
        seriesNameEnd = i - 1
      } else {
        break
      }
    }

    if (seriesNameEnd < 0) seriesNameEnd = 0

    const seriesRaw = dirSegments.slice(0, seriesNameEnd + 1).join(' ')
    const seriesName = cleanSeriesFolderName(seriesRaw)
    const folderPath = allSegs.slice(0, rootMatch.segmentCount + seriesNameEnd + 1).join('/')

    if (!seriesName) return null
    return { seriesName, season, fileName, folderPath }
  }

  // ── Group episodes by parsed series name ──
  interface Group {
    seriesName: string
    year: number | null
    episodes: { epId: string; oldSeriesId: string; fileName: string; season: number }[]
  }

  const groups = new Map<string, Group>()
  let skipped = 0

  for (const ep of allEps) {
    const parsed = parsePath(ep.filePath)
    if (!parsed) { skipped++; continue }

    const key = parsed.seriesName.toLowerCase()
    const existing = groups.get(key)

    if (existing) {
      existing.episodes.push({
        epId: ep.id, oldSeriesId: ep.seriesId,
        fileName: parsed.fileName, season: parsed.season,
      })
    } else {
      const folderName = parsed.folderPath.split('/').pop() || ''
      const year = extractYearFromFolderName(folderName)
      groups.set(key, {
        seriesName: parsed.seriesName, year,
        episodes: [{
          epId: ep.id, oldSeriesId: ep.seriesId,
          fileName: parsed.fileName, season: parsed.season,
        }],
      })
    }
  }

  // ── Assign primary series ──
  const matchLog: string[] = []
  const groupPrimaryId = new Map<string, string>()

  for (const [key, group] of groups) {
    const counts = new Map<string, number>()
    for (const ep of group.episodes) {
      counts.set(ep.oldSeriesId, (counts.get(ep.oldSeriesId) || 0) + 1)
    }
    let bestId = group.episodes[0].oldSeriesId
    let bestCount = 0
    for (const [id, count] of counts) {
      if (count > bestCount) { bestCount = count; bestId = id }
    }
    groupPrimaryId.set(key, bestId)

    const bestSeries = allSeries.find(s => s.id === bestId)
    if (bestSeries && bestSeries.title.toLowerCase() !== key) {
      matchLog.push(`"${bestSeries.title}" → "${group.seriesName}" (${group.episodes.length} eps de ${counts.size} series)`)
    }
  }

  // ── Build diagnostics ──
  diagnostics.push(`Carpetas configuradas: ${seriesFolders.map(f => `"${f.trim()}"`).join(', ')}`)
  diagnostics.push(`Total episodios: ${allEps.length}`)
  diagnostics.push(`Episodios procesados: ${allEps.length - skipped}`)
  if (skipped > 0) {
    diagnostics.push(`Episodios sin coincidencia: ${skipped}`)
    diagnostics.push('Ejemplos de rutas sin match:')
    for (const s of unmatchedSamples) diagnostics.push(`  → ${s}`)
  }
  if (matchLog.length > 0) {
    diagnostics.push('Nombres corregidos:')
    for (const log of matchLog) diagnostics.push(`  ${log}`)
  }
  diagnostics.push(`Series finales: ${groups.size}`)

  if (groups.size === 0) {
    return NextResponse.json({
      success: false,
      message: 'No se pudo determinar la estructura. Verifica las rutas en Configuración.',
      diagnostics,
    })
  }

  if (dryRun) {
    const summary = [...groups.values()].map(g => `${g.seriesName} (${g.episodes.length} eps)`).join('\n')
    return NextResponse.json({
      success: true, dryRun: true,
      message: `VISTA PREVIA - ${groups.size} series, ${allEps.length - skipped} episodios`,
      stats: { totalGroups: groups.size, updatedEps: 0, mergedEps: 0, deletedSeries: 0, skipped },
      summary, diagnostics,
    })
  }

  // ── Sort episodes within each group ──
  for (const group of groups.values()) {
    group.episodes.sort((a, b) => {
      if (a.season !== b.season) return a.season - b.season
      const numA = a.fileName.match(/(\d+)/)
      const numB = b.fileName.match(/(\d+)/)
      if (numA && numB) {
        const diff = parseInt(numA[1], 10) - parseInt(numB[1], 10)
        if (diff !== 0) return diff
      }
      return a.fileName.localeCompare(b.fileName)
    })
  }

  // ── Apply to database ──
  let mergedEps = 0
  let updatedEps = 0

  for (const [key, group] of groups) {
    const primaryId = groupPrimaryId.get(key)!
    const primary = allSeries.find(s => s.id === primaryId)

    if (primary) {
      await db.movie.update({ where: { id: primaryId }, data: { title: group.seriesName } })
    }

    if (group.year && primary && (!primary.year || primary.year === 2024)) {
      await db.movie.update({ where: { id: primaryId }, data: { year: group.year } })
    }

    const seasonCounter = new Map<number, number>()

    for (const ep of group.episodes) {
      const cnt = (seasonCounter.get(ep.season) || 0) + 1
      seasonCounter.set(ep.season, cnt)

      if (ep.oldSeriesId !== primaryId) {
        await db.episode.update({
          where: { id: ep.epId },
          data: { seriesId: primaryId, seasonNumber: ep.season, episodeNumber: cnt, title: `Episodio ${cnt}` },
        })
        mergedEps++
      } else {
        await db.episode.update({
          where: { id: ep.epId },
          data: { seasonNumber: ep.season, episodeNumber: cnt },
        })
      }
      updatedEps++
    }
  }

  // Delete empty series
  const remaining = await db.movie.findMany({ where: { type: 'series' }, include: { episodes: true } })
  let deletedSeries = 0
  for (const s of remaining) {
    if (s.episodes.length === 0) {
      await db.movie.delete({ where: { id: s.id } })
      deletedSeries++
    }
  }

  const summary = [...groups.values()].map(g => {
    const pid = groupPrimaryId.get(g.seriesName.toLowerCase())!
    const p = allSeries.find(s => s.id === pid)
    const omdb = p?.coverImage && !p.coverImage.includes('default') ? ' ✓' : ''
    return `${g.seriesName} (${g.episodes.length} eps)${omdb}`
  }).join(', ')

  const msg = `Reorganizado: ${groups.size} series, ${updatedEps} episodios, ${mergedEps} fusionados, ${deletedSeries} eliminadas.${skipped > 0 ? ` (${skipped} sin ruta)` : ''}`

  return NextResponse.json({
    success: true, message: msg,
    stats: { totalGroups: groups.size, updatedEps, mergedEps, deletedSeries, skipped },
    summary, diagnostics,
  })
}

// ─── Reorganize Movies ────────────────────────────────────────────

async function handleReorganizeMovies(dryRun: boolean) {
  const allMovies = await db.movie.findMany({
    where: { type: 'movie', local: true },
  })

  if (allMovies.length === 0) {
    return NextResponse.json({ success: false, message: 'No hay películas locales en la base de datos. Primero importa desde HD.' })
  }

  const config = getConfig()
  const moviesFolders = (config.moviesFolders || []).filter(f => f.trim())

  if (moviesFolders.length === 0) {
    return NextResponse.json({ success: false, message: 'No hay carpetas de películas configuradas.' })
  }

  // ── Path normalization ──
  function normalizePath(p: string): string {
    return p.replace(/\\/g, '/').replace(/\/+$/, '').toLowerCase()
  }

  function toSegments(p: string): string[] {
    return p.replace(/\\/g, '/').replace(/\/+$/, '').split('/').filter(Boolean)
  }

  // ── Pre-compute normalized roots (longest first) ──
  const roots = moviesFolders.map(f => {
    const trimmed = f.trim()
    const norm = normalizePath(trimmed)
    const segs = toSegments(trimmed)
    return { original: trimmed, normalized: norm, segmentCount: segs.length }
  }).sort((a, b) => b.normalized.length - a.normalized.length)

  function findRootSegments(filePath: string): { rootOriginal: string; segmentCount: number } | null {
    const normFile = normalizePath(filePath)
    for (const root of roots) {
      if (normFile === root.normalized || normFile.startsWith(root.normalized + '/')) {
        return { rootOriginal: root.original, segmentCount: root.segmentCount }
      }
    }
    return null
  }

  // ── Parse file path → movie name ──
  const diagnostics: string[] = []
  const unmatchedSamples: string[] = []

  interface MovieGroup {
    movieName: string
    year: number | null
    movieIds: string[]
  }

  const groups = new Map<string, MovieGroup>()
  let skipped = 0

  for (const movie of allMovies) {
    const filePath = movie.filePath
    if (!filePath) { skipped++; continue }

    const rootMatch = findRootSegments(filePath)
    if (!rootMatch) {
      if (unmatchedSamples.length < 5) unmatchedSamples.push(filePath)
      skipped++
      continue
    }

    const allSegs = toSegments(filePath)
    const fileName = allSegs.pop()!
    const dirSegments = allSegs.slice(rootMatch.segmentCount)

    // The movie name comes from the parent folder name (or filename if flat)
    let movieRaw: string
    if (dirSegments.length > 0) {
      // Use the last non-season folder name
      movieRaw = dirSegments[dirSegments.length - 1]
    } else {
      movieRaw = fileName.replace(/\.[^.]+$/, '')
    }

    const year = extractYearFromFolderName(dirSegments.length > 0 ? dirSegments[dirSegments.length - 1] : fileName)
    const movieName = cleanTitle(movieRaw)

    if (!movieName) { skipped++; continue }

    const key = movieName.toLowerCase()
    const existing = groups.get(key)

    if (existing) {
      if (!existing.movieIds.includes(movie.id)) {
        existing.movieIds.push(movie.id)
      }
    } else {
      groups.set(key, { movieName, year, movieIds: [movie.id] })
    }
  }

  // ── Assign primary movie ──
  const matchLog: string[] = []
  const groupPrimaryId = new Map<string, string>()

  for (const [key, group] of groups) {
    // Pick the one with a real cover if possible
    let bestId = group.movieIds[0]
    for (const id of group.movieIds) {
      const m = allMovies.find(m => m.id === id)
      if (m && m.coverImage && !m.coverImage.includes('default')) {
        bestId = id
        break
      }
    }
    groupPrimaryId.set(key, bestId)

    for (const id of group.movieIds) {
      if (id !== bestId) {
        const m = allMovies.find(m => m.id === id)
        if (m) {
          matchLog.push(`"${m.title}" → "${group.movieName}" (fusionada)`)
        }
      }
    }
  }

  diagnostics.push(`Carpetas configuradas: ${moviesFolders.map(f => `"${f.trim()}"`).join(', ')}`)
  diagnostics.push(`Total películas locales: ${allMovies.length}`)
  diagnostics.push(`Películas procesadas: ${allMovies.length - skipped}`)
  if (skipped > 0) {
    diagnostics.push(`Películas sin coincidencia: ${skipped}`)
    for (const s of unmatchedSamples) diagnostics.push(`  → ${s}`)
  }
  if (matchLog.length > 0) {
    diagnostics.push('Fusiones:')
    for (const log of matchLog) diagnostics.push(`  ${log}`)
  }
  diagnostics.push(`Películas finales: ${groups.size}`)

  if (groups.size === 0) {
    return NextResponse.json({
      success: false,
      message: 'No se pudo determinar la estructura. Verifica las rutas.',
      diagnostics,
    })
  }

  if (dryRun) {
    const summary = [...groups.values()].map(g => `${g.movieName} (${g.movieIds.length} entries)`).join('\n')
    return NextResponse.json({
      success: true, dryRun: true,
      message: `VISTA PREVIA - ${groups.size} películas`,
      stats: { totalGroups: groups.size, mergedMovies: 0, deletedMovies: 0, skipped },
      summary, diagnostics,
    })
  }

  // ── Apply to database ──
  let mergedMovies = 0
  let deletedMovies = 0

  for (const [key, group] of groups) {
    const primaryId = groupPrimaryId.get(key)!
    const primary = allMovies.find(m => m.id === primaryId)

    // Update title
    if (primary) {
      await db.movie.update({ where: { id: primaryId }, data: { title: group.movieName } })
    }

    // Update year
    if (group.year && primary && (!primary.year || primary.year === 2024)) {
      await db.movie.update({ where: { id: primaryId }, data: { year: group.year } })
    }

    // Merge duplicates into primary
    for (const id of group.movieIds) {
      if (id !== primaryId) {
        // Reassign episodes (unlikely for movies but just in case)
        await db.episode.updateMany({
          where: { seriesId: id },
          data: { seriesId: primaryId },
        })
        // Reassign favorites
        await db.favorite.updateMany({
          where: { movieId: id },
          data: { movieId: primaryId },
        })
        // Reassign watch progress
        await db.watchProgress.updateMany({
          where: { movieId: id },
          data: { movieId: primaryId },
        })
        // Delete duplicate
        await db.movie.delete({ where: { id } })
        mergedMovies++
      }
    }
  }

  const summary = [...groups.values()].map(g => {
    const pid = groupPrimaryId.get(g.movieName.toLowerCase())!
    const p = allMovies.find(m => m.id === pid)
    const omdb = p?.coverImage && !p.coverImage.includes('default') ? ' ✓' : ''
    return `${g.movieName}${omdb}`
  }).join(', ')

  const msg = `Reorganizado: ${groups.size} películas, ${mergedMovies} fusionadas.${skipped > 0 ? ` (${skipped} sin ruta)` : ''}`

  return NextResponse.json({
    success: true, message: msg,
    stats: { totalGroups: groups.size, mergedMovies, deletedMovies, skipped },
    summary, diagnostics,
  })
}

// ─── DELETE: Clean database ───────────────────────────────────────

export async function DELETE() {
  try {
    const deletedEps = await db.episode.deleteMany({})
    const deletedFavs = await db.favorite.deleteMany({})
    const deletedProgress = await db.watchProgress.deleteMany({})
    const deletedMovies = await db.movie.deleteMany({})
    return NextResponse.json({
      success: true,
      message: `Eliminados: ${deletedMovies.count} títulos, ${deletedEps.count} episodios`,
    })
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 })
  }
}