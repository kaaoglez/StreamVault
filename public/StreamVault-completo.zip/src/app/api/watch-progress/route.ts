import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET: Fetch movies/episodes with watch progress (for "Continuar Viendo")
export async function GET() {
  try {
    const progressEntries = await db.watchProgress.findMany({
      where: { progress: { gt: 0, lt: 100 } }, // 0-99% = in progress
      orderBy: { lastWatched: 'desc' },
      include: {
        movie: {
          include: {
            episodes: {
              where: { id: undefined as unknown as string }, // placeholder, filtered below
              take: 0,
            },
          },
        },
      },
    })

    // Deduplicate by movieId (show latest progress per movie)
    const seen = new Map<string, typeof progressEntries[0]>()
    for (const entry of progressEntries) {
      const existing = seen.get(entry.movieId)
      if (!existing || entry.lastWatched > existing.lastWatched) {
        seen.set(entry.movieId, entry)
      }
    }

    const result = Array.from(seen.values()).map((entry) => ({
      ...entry.movie,
      watchProgress: entry.progress,
      lastWatched: entry.lastWatched.toISOString(),
      episodeId: entry.episodeId || undefined,
      isFavorite: false,
    }))

    return NextResponse.json({ movies: result })
  } catch (error) {
    console.error('Error fetching watch progress:', error)
    return NextResponse.json(
      { error: 'Failed to fetch watch progress' },
      { status: 500 }
    )
  }
}

// POST: Save/update watch progress (supports episode-level)
export async function POST(request: NextRequest) {
  try {
    const { movieId, episodeId, progress } = await request.json()

    if (!movieId || progress === undefined) {
      return NextResponse.json(
        { error: 'movieId and progress are required' },
        { status: 400 }
      )
    }

    // Check if movie exists
    const movie = await db.movie.findUnique({ where: { id: movieId } })
    if (!movie) {
      return NextResponse.json({ error: 'Movie not found' }, { status: 404 })
    }

    // If episodeId provided, validate it exists
    if (episodeId) {
      const episode = await db.episode.findUnique({ where: { id: episodeId } })
      if (!episode) {
        return NextResponse.json({ error: 'Episode not found' }, { status: 404 })
      }
    }

    // If progress is 100%, delete the progress entry (fully watched)
    if (progress >= 100) {
      await db.watchProgress.deleteMany({
        where: {
          movieId,
          ...(episodeId ? { episodeId } : { episodeId: null }),
        },
      })
      return NextResponse.json({ success: true, progress: 100 })
    }

    // Upsert watch progress
    const existing = await db.watchProgress.findFirst({
      where: {
        movieId,
        ...(episodeId ? { episodeId } : { episodeId: null }),
      },
    })

    if (existing) {
      await db.watchProgress.update({
        where: { id: existing.id },
        data: { progress, lastWatched: new Date() },
      })
    } else {
      await db.watchProgress.create({
        data: {
          movieId,
          episodeId: episodeId || null,
          progress,
          lastWatched: new Date(),
        },
      })
    }

    return NextResponse.json({ success: true, progress })
  } catch (error) {
    console.error('Error updating watch progress:', error)
    return NextResponse.json(
      { error: 'Failed to update watch progress' },
      { status: 500 }
    )
  }
}