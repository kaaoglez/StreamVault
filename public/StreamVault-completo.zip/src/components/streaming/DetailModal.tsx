'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Play, Plus, Heart, Star, Clock, HardDrive, Globe, Award, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { useAppStore, type Movie, type Episode } from '@/store/app-store';
import { cn } from '@/lib/utils';

export function DetailModal() {
  const { selectedMovie, isDetailOpen, closeDetail, openPlayer } =
    useAppStore();
  const [movieDetails, setMovieDetails] = useState<Movie | null>(null);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [loading, setLoading] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);

  const fetchDetails = useCallback(async (movieId: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/movies/${movieId}`);
      if (res.ok) {
        const data = await res.json();
        setMovieDetails(data);
        setEpisodes(data.episodes || []);
      }
    } catch {
      setMovieDetails(selectedMovie);
    } finally {
      setLoading(false);
    }
  }, [selectedMovie]);

  // Check favorite status
  const checkFavorite = useCallback(async (movieId: string) => {
    try {
      const res = await fetch('/api/favorites');
      if (res.ok) {
        const data = await res.json();
        const fav = (data.favorites || []).find((f: { movieId: string }) => f.movieId === movieId);
        setIsFavorited(!!fav);
      }
    } catch {}
  }, []);

  const toggleFavorite = useCallback(async (movieId: string) => {
    try {
      const res = await fetch('/api/favorites', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ movieId }),
      });
      if (res.ok) {
        const data = await res.json();
        setIsFavorited(data.favorited);
      }
    } catch {}
  }, []);

  useEffect(() => {
    if (isDetailOpen && selectedMovie) {
      document.body.style.overflow = 'hidden';
      fetchDetails(selectedMovie.id);
      checkFavorite(selectedMovie.id);
    } else {
      document.body.style.overflow = '';
      setMovieDetails(null);
      setEpisodes([]);
      setIsFavorited(false);
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isDetailOpen, selectedMovie, fetchDetails, checkFavorite]);

  if (!isDetailOpen) return null;

  const movie = movieDetails || selectedMovie;
  if (!movie) return null;

  const genres = movie.genre.split(',').map((g) => g.trim());
  const backdropUrl = movie.backdropImage;

  // Group episodes by season
  const seasons: Record<number, Episode[]> = {};
  episodes.forEach((ep) => {
    if (!seasons[ep.seasonNumber]) {
      seasons[ep.seasonNumber] = [];
    }
    seasons[ep.seasonNumber].push(ep);
  });
  const sortedSeasons = Object.keys(seasons).sort(
    (a, b) => Number(a) - Number(b)
  );

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[90] overflow-y-auto"
      >
        {/* Backdrop */}
        <div
          className="fixed inset-0 bg-black/70 backdrop-blur-sm"
          onClick={closeDetail}
        />

        {/* Modal Content */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative min-h-screen"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Close Button */}
          <button
            onClick={closeDetail}
            className="fixed top-4 right-4 z-[95] w-10 h-10 rounded-full bg-[#181818] hover:bg-[#252525] flex items-center justify-center transition-colors"
            aria-label="Close"
          >
            <X className="h-5 w-5 text-white" />
          </button>

          {/* Backdrop Image */}
          <div className="relative h-[60vh] min-h-[400px]">
            {loading ? (
              <Skeleton className="w-full h-full bg-[#222]" />
            ) : (
              <img
                src={backdropUrl}
                alt={movie.title}
                className="w-full h-full object-cover"
                onError={(e) => {
                  const el = e.target as HTMLImageElement;
                  el.style.display = 'none';
                }}
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-[#141414]/60 to-transparent" />
          </div>

          {/* Content */}
          <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 -mt-48 relative z-10 pb-20">
            {loading ? (
              <div className="space-y-4">
                <Skeleton className="h-10 w-3/4 bg-[#222]" />
                <Skeleton className="h-4 w-1/2 bg-[#222]" />
                <Skeleton className="h-20 w-full bg-[#222]" />
              </div>
            ) : (
              <>
                {/* Title and Meta */}
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-3">
                  {movie.title}
                </h1>

                <div className="flex flex-wrap items-center gap-3 mb-4 text-sm">
                  <span className="text-green-400 font-semibold flex items-center gap-1">
                    <Star className="h-4 w-4 fill-green-400 text-green-400" />
                    {movie.rating.toFixed(1)}
                  </span>
                  <span className="text-gray-400">{movie.year}</span>
                  {movie.duration && (
                    <span className="text-gray-400 flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      {movie.duration}
                    </span>
                  )}
                  <Badge
                    variant="secondary"
                    className="bg-white/20 text-white text-xs hover:bg-white/30"
                  >
                    {movie.maturity}
                  </Badge>
                  <Badge
                    variant="outline"
                    className="border-white/20 text-gray-300 text-xs bg-white/5"
                  >
                    {movie.type === 'series' ? 'Serie' : 'Película'}
                  </Badge>
                  {movie.featured && (
                    <Badge className="bg-[#e50914] text-white text-xs hover:bg-[#e50914] border-0">
                      <Award className="h-3 w-3 mr-1" />
                      Destacado
                    </Badge>
                  )}
                </div>

                {/* Genre Tags */}
                <div className="flex flex-wrap gap-2 mb-5">
                  {genres.map((genre) => (
                    <Badge
                      key={genre}
                      variant="outline"
                      className="border-white/20 text-gray-300 text-xs bg-white/5 hover:bg-white/10"
                    >
                      {genre}
                    </Badge>
                  ))}
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-3 mb-6">
                  <Button
                    size="lg"
                    className="btn-primary text-base px-8 h-12 rounded-md font-semibold"
                    onClick={() => openPlayer(movie)}
                  >
                    <Play className="h-5 w-5 mr-2 fill-white" />
                    Reproducir
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className={cn(
                      "border-white/20 bg-white/10 text-white hover:bg-white/20 hover:text-white px-6 h-12 rounded-md",
                      isFavorited && "bg-[#e50914]/20 border-[#e50914]"
                    )}
                    onClick={() => movie && toggleFavorite(movie.id)}
                  >
                    <Plus className={cn("h-5 w-5 mr-2", isFavorited && "fill-white")} />
                    {isFavorited ? 'En Mi Lista' : 'Mi Lista'}
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className={cn(
                      "border-white/20 bg-white/10 text-white hover:bg-white/20 hover:text-white px-6 h-12 rounded-md",
                      isFavorited && "text-[#e50914]"
                    )}
                    onClick={() => movie && toggleFavorite(movie.id)}
                  >
                    <Heart className={cn("h-5 w-5 mr-2", isFavorited && "fill-[#e50914] text-[#e50914]")} />
                    Me Gusta
                  </Button>
                </div>

                {/* Description */}
                <p className="text-gray-300 text-base md:text-lg leading-relaxed mb-6 max-w-3xl">
                  {movie.description}
                </p>

                {/* Technical Info */}
                <div className="mb-8 p-4 rounded-lg bg-white/5 border border-white/10 max-w-3xl">
                  <div className="flex items-center gap-2 mb-3">
                    {movie.local ? (
                      <HardDrive className="h-4 w-4 text-[#e50914]" />
                    ) : (
                      <Globe className="h-4 w-4 text-blue-400" />
                    )}
                    <span className="text-sm font-medium text-gray-300">
                      {movie.local ? 'Archivo Local (HD)' : 'Contenido Remoto'}
                    </span>
                  </div>
                  {movie.filePath && (
                    <p className="text-xs text-gray-500 font-mono break-all select-all cursor-text">
                      {movie.filePath}
                    </p>
                  )}
                  {movie.videoUrl && !movie.local && (
                    <p className="text-xs text-gray-500 font-mono break-all mt-1">
                      {movie.videoUrl}
                    </p>
                  )}
                  <div className="flex items-center gap-4 mt-3 pt-3 border-t border-white/10">
                    <span className="text-xs text-gray-500 flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      Agregado: {new Date(movie.createdAt).toLocaleDateString('es-ES', { year: 'numeric', month: 'short', day: 'numeric' })}
                    </span>
                    <span className="text-xs text-gray-500">
                      Actualizado: {new Date(movie.updatedAt).toLocaleDateString('es-ES', { year: 'numeric', month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                </div>

                {/* Episodes for Series */}
                {movie.type === 'series' && sortedSeasons.length > 0 && (
                  <div className="mb-8">
                    <h2 className="text-2xl font-bold text-white mb-4">
                      Episodios
                    </h2>
                    <Accordion type="single" collapsible defaultValue="season-1">
                      {sortedSeasons.map((seasonNum) => (
                        <AccordionItem
                          key={`season-${seasonNum}`}
                          value={`season-${seasonNum}`}
                          className="border-white/10"
                        >
                          <AccordionTrigger className="text-white hover:no-underline hover:text-white/80 py-4 text-base">
                            <span className="flex items-center gap-3">
                              <span className="text-[#e50914] font-semibold">
                                Temporada {seasonNum}
                              </span>
                              <span className="text-gray-500 text-sm">
                                {seasons[Number(seasonNum)].length} episodios
                              </span>
                            </span>
                          </AccordionTrigger>
                          <AccordionContent className="pb-4">
                            <div className="space-y-2">
                              {seasons[Number(seasonNum)]
                                .sort(
                                  (a, b) => a.episodeNumber - b.episodeNumber
                                )
                                .map((episode) => (
                                  <button
                                    key={episode.id}
                                    className="w-full flex items-center gap-4 p-3 rounded-lg bg-[#222] hover:bg-[#2a2a2a] transition-colors text-left group"
                                    onClick={() =>
                                      openPlayer(movie, episode)
                                    }
                                  >
                                    {/* Episode Number */}
                                    <span className="text-2xl font-bold text-gray-500 w-10 text-center shrink-0">
                                      {episode.episodeNumber}
                                    </span>

                                    {/* Play Icon */}
                                    <div className="w-8 h-8 rounded-full border-2 border-gray-500 group-hover:border-white flex items-center justify-center shrink-0 transition-colors">
                                      <Play className="h-3.5 w-3.5 text-gray-500 group-hover:text-white transition-colors ml-0.5" />
                                    </div>

                                    {/* Info */}
                                    <div className="flex-1 min-w-0">
                                      <div className="flex items-center gap-2">
                                        <span className="text-sm font-medium text-white truncate">
                                          {episode.title}
                                        </span>
                                        {episode.duration && (
                                          <span className="text-xs text-gray-500 shrink-0">
                                            {episode.duration}
                                          </span>
                                        )}
                                      </div>
                                      {episode.description && (
                                        <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">
                                          {episode.description}
                                        </p>
                                      )}
                                    </div>
                                  </button>
                                ))}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  </div>
                )}
              </>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
